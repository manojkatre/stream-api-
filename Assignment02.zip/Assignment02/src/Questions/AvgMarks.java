package Questions;
//calculate avg marks of students from list of students
import java.util.*;
public class AvgMarks {

	public static void main(String[] args) {
		
		
		
		List<Integer> intList = Arrays.asList(1,2,2,3,1,5);

		float av = (float) intList.stream().mapToInt(val -> val).average().orElse(0.0);
		System.out.println("average of number found to be:"+av);

	}

}
