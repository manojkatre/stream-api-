package Questions;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

//create list of student whose name starting with 'a'
public class StudentName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> student=new ArrayList<String>();
		student.add("vishal");
		student.add("rahul");
		student.add("sharma");
		student.add("aravind");
		student.add("Ashish");
		
		
		/*for(String name : student)
		{
			if(name.startsWith("a"))
				System.out.println(name);
		} */
		
		List<String> list=student.stream().filter(obj->obj.startsWith("A")||obj.startsWith("a")).collect(Collectors.toList());
		
		System.out.println(list);

	}

}
