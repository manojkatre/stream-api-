package Questions;
import java.util.*;
import java.util.stream.Collectors;
class Info
{
	String name;
	int population,area;
	public Info(String name, int population, int area) {
	
		this.name = name;
		this.population = population;
		this.area = area;
	}
	
}
public class City {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Info> I=new ArrayList<Info>();
		I.add(new Info("nagpur",50000,25000));
		I.add(new Info("Wardha",55000,19000));
		I.add(new Info("Mumbai",58000,40000));
		I.add(new Info("Indor",45000,35000));
		I.add(new Info("Pune",89000,45000));
		
		Info obj=I.stream().max((obj1,obj2)->obj1.population>obj2.population ?1:-1).get();
		System.out.println("The highest population is :"+obj.population);
		System.out.println("Name of city which has Highest population :"+obj.name);
		
		Set<Integer>pop=I.stream().map(e->e.population).collect(Collectors.toSet());
		System.out.println("Population :"+pop);
		
		Info objmin=I.stream().min((obj1,obj2)->obj1.area>obj2.area ?1:-1).get();
		System.out.println("The Lowest Area is :"+objmin.area);
		System.out.println("Name of city which has Lowest Area :"+objmin.name);
		
		
	}

}
